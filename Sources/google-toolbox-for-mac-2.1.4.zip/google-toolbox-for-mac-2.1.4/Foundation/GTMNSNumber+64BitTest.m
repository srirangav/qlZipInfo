//
// This file previously included tests for utility methods
// for creating 64-bit NSNumbers.
//
// Applications should be updated to use NSNumber literals
// and boxed expressions, as described at
// http://clang.llvm.org/docs/ObjectiveCLiterals.html
//
